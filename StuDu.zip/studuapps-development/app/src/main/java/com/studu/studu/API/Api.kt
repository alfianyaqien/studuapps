package com.studu.studu.API

interface Api {

}