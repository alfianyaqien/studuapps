package com.studu.studu.API

data class CreatePostResponse()
